<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>


    <style>
    
    
.navbar{margin-bottom:0;}
section{width:100%;height: 100%; float:left;}
.banner-section{background-image:url("https://static.pexels.com/photos/373912/pexels-photo-373912.jpeg"); background-size:cover; height: 380px; left: 0; position: absolute; top: 0; background-position:0;}
.post-title-block{padding:100px 0;}
.post-title-block h1{color: #fff; font-size: 85px; font-weight: bold; text-transform: capitalize;}
.post-title-block li{font-size:20px; color: #fff;}
.image-block{float:left; width:100%; margin-bottom:10px;}
.footer-link{float:left; width:100%; background:#222222; text-align:center; padding:30px;}
.footer-link a{color:grey; font-size:18px; text-transform:uppercase;}
    
div{
height: 100%;


}    
    </style>

</head>
<body>


    <?php 
        session_start();
        
            $_SESSION['Userame'];
            
	if($_SESSION['Userame']==null ||$_SESSION['Userame']=='')
			{
			header('location:../index.html');
	}else{

	?>
    
    <nav class="navbar navbar-inverse  navbar-static-top">
        <div class="container">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="">EASY WORK</a>
          </div>
          <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
              <li class="active"><a href="Principal.html">INICIO</a></li>
              <li><a href="#about">Sobre</a></li>
                <li class="navbar-brand">PRUEBAS
                    <select name="PRUEBAS" value="PRUEBAS">
                       <option value="PREUBA1">
                          P.PSICOTECNICA
     
                       </option>
                       <option value="PRUEBA2">
                         P.PSICOLOGICA
                       </option>
                       <option value="PRUEBA3">
                          P.CAPACIDAD MENTAL
                        </option>
                        <option value="PRUEBA4">
                            P.CONOCIMIENTO
                          </option>
                     </select>
                     
                   <li>
                       <a href='../logoutsalir.php'  class='login-button-2 text-uppercase text-wh mt-lg-0 mt-2'>CERRAR SESION</a></li>

                   </li>
              
              </li>
            
              </ul>

              
         </div><!--/.nav-collapse -->
        </div>
      </nav>

      
  
  <section class="banner-section">
  </section>
  <section class="post-content-section">
      <div class="container">
  
          <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12 post-title-block">
                 
                  <h1 class="text-center" style="color: #BB6600">BIENVENIDO ASPIRANTE</h1>
                  <ul class="list-inline text-center">
                      <li>Esta es su oportunidad |</li>
                      <li>Esperamos |</li>
                      <li>Lo Mejor |</li>
                  </ul>
              </div>
              <div class="col-lg-9 col-md-9 col-sm-12">
      
  
               </div>
          
                  <div class="well" style="height: 5000px">
                    
                      <center><img src="Fondo1.jpg" class="img-rounded" /></center>
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna</p>
                      <a href="#" class="btn btn-default">Read more</a>
                       <br>
                       <br>
                       <br>

                      <center><img src="Fondo2.png" class="img-rounded"/></center>


                  </div>

              </div>
        
  
      </div> <!-- /container -->
  </section>
  
<section class="footer-link"><a href="http://bootsnipp.com/grafreez" target="_blank">View Our All Snnips</a></section>



<?php


}

?> 


</body>
</html>

<?php
 

$a=$_POST['Userame'];
$b=$_POST['Password'];


$conn=mysqli_connect('localhost:3306', 'root','', 'easywork' );
$sql3="SELECT * FROM usuario WHERE doc= $a and clave = '$b' and  cargo=10 ";
$resul1=mysqli_query($conn,$sql3); 

$linea=mysqli_fetch_array($resul1);


$f=$linea[0];
$g=$linea[7];


if($a==$f && $b==$g){
    session_start();
 $_SESSION['Userame']=$a;
    header('location:indexadmi.php'); 

}

else if($a<>$f && $b<>$g){
    session_start();
  
   echo '<script language="javascript">alert("Usuario o contraseña incorrecto");window.location.href="http://localhost/easywork/ew/ew/index.html"</script>';
  


}else{


    session_start();



$_SESSION['Userame'];
include('logout.php');

}



?>

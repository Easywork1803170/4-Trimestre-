<!DOCTYPE html>
<html>

<head>

		<title>EASY WORK</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="keywords" content="Library Member Login Form Widget Responsive, Login Form Web Template, Flat Pricing Tables, Flat Drop-Downs, Sign-Up Web Templates, Flat Web Templates, Login Sign-up Responsive Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design" />
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	 	<link rel="stylesheet" href="../estilo2.css" type="text/css" media="all">
		<link href="//fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
		<style>
			.color{
				color:#E7ECF0;

			}

			.container {
			position: absolute;    
			top: 18%;
			left: 30%;
			width: 30%;
			height:40%;
			margin: 0 auto;
			padding: 40px;
			background-color: rgba(10, 10, 10, 0.77);
			border: 2px ridge rgba(238, 238, 238, 0.13);
			border-radius: 5px;
			-moz-box-shadow: 0 -5px 10px 1px rgba(16, 16, 16, 0.57);
			-webkit-box-shadow: 0 -5px 10px 1px rgba(16, 16, 16, 0.57);
			box-shadow: 0 -5px 10px 1px rgba(16, 16, 16, 0.57);
			border-bottom: none;
			border-bottom-left-radius: initial;
			border-bottom-right-radius: initial;
			}	

		</style>	

</head>

<body>




	<h1> </h1>

	<div class="container w3layouts agileits" >

		<div class="login w3layouts agileits" >
			<h2>Mensaje enviado Exitosamente</h2>
			<h5>Se ha enviado un mensaje a tu correo para restablecer tu contraseña</h5>
			<br>
			<form action="conectar.php" method="post">

				
			</form>

			</div>
		</div>
	</div>
</body>
</html>
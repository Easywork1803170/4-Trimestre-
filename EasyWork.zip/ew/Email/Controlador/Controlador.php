<?php

require_once("../Modelo/Modelo.php");
$BD1 = new BaseDatos();
$BD1->conectar();



$Email=$_POST["Email"];
$BD1->conectar();
$BD1->identificar($Email);
require_once("../vistas/Mensaje.php")






?>
<?php

require_once("../Modelo/Modelo.php");
$BD2 = new BaseDatos();
$BD2->conectar();


$Newpass=$_POST["contraseña"];
$Newemail=$_POST["Email"];
$BD2->actualizar($Newpass,$Newemail);
require_once("../vistas/Vista2.php")



?>
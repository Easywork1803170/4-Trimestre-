<?php
require_once("constructor.php");
$p = new oper();

$a=$_POST['in'];




if($a =='Ingresar pregunta')
{
    $pre=$_POST['a'];
    $res1=$_POST['b'];
    $res2=$_POST['c'];
    $res3=$_POST['d'];
    $res4=$_POST['e'];
    $rtrue=$_POST['f'];
   // $con->conexion();
    $p->agregar($pre,$res1,$res2,$res3,$res4,$rtrue);
}

if($a=='prueba')
{
    //$con->conexion();
    $p->prueba();
}

if($a=='Responder')
{

    $res=$_POST['opcion'];
    $res1=$_POST['opcion1'];
    $res2=$_POST['opcion2'];
    $res3=$_POST['opcion3'];
    $res4=$_POST['opcion4'];
    $res5=$_POST['opcion5'];
    $res6=$_POST['opcion6'];
    $res7=$_POST['opcion7'];
    $res8=$_POST['opcion8'];
    $res9=$_POST['opcion9'];

    //$con->conexion();
    $p->resulado($res,$res1,$res2,$res3,$res4,$res5,$res6,$res7,$res8,$res9);
}





?>
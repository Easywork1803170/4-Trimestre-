<?php
   
 class oper 
{
  
 public function agregar($a,$b,$c,$d,$e,$f)
 {

    $con = mysqli_connect("localhost:3306","root","","easywork") or die(mysql_error());

     
         mysqli_query($con,"insert into pregunta (pregunta) values ('$a')");
         mysqli_query($con,"insert into respuestas (res1,res2,res3,res4,verd) values ('$b','$c','$d','$e','$f')");

    
        echo"<script type='text/javascript'>
        alert(' datos agregados');
        window.location.href='../addquest/add.html';
        </script>";
     
    



 }

 public function prueba ()

 {

    

echo "<body>";

    echo "<form method='POST' action='../modelo/modelo.php'>";

$con = mysqli_connect("localhost:3306","root","","easywork") or die(mysql_error());
   
    $result= mysqli_query($con,"select * from pregunta where id_pre=1");

    $row = mysqli_fetch_row($result);
    
     $id=$row[0];
     $nom=$row[1];   
         

    
    echo "<br>";
    echo "<center>";
    echo "<table background='blue' width='400' border=3>";
    echo "<tr>"; 
    echo "<td colpan='2'><strong>Pregunta</strong>: $nom"; 
    echo "</tr>";
    
    $result= mysqli_query($con,"select res1,res2,res3,res4 from respuestas where id_res=1");

    $row = mysqli_fetch_row($result);
    
     $res1=$row[0];
     $res2=$row[1];
     $res3=$row[2];
     $res4=$row[3]; 

   echo "<tr>";
  
   echo "<td width='51' >$res1<input type='radio' name='opcion' value='$res1'";
   echo "<td width='51'>$res2<input type='radio' name='opcion' value='$res2'";
   echo "<td width='51'>$res3<input type='radio' name='opcion' value='$res3'";
   echo "<td width='51'>$res4<input type='radio' name='opcion' value='$res4'";
   
   echo "</tr>";
   echo "</table>";

  // prueba 2
  
  $result= mysqli_query ($con,"select * from pregunta where id_pre=2");

    $row = mysqli_fetch_row($result);
    
     $id=$row[0];
     $nom=$row[1];   
         

    
    echo "<br>";
    echo "<table width='400' border='3'>";
    echo "<tr>"; 
    echo "<td colpan='2'><strong>Pregunta</strong>: $nom"; 
    echo "</tr>";
    $result= mysqli_query($con,"select res1,res2,res3,res4 from respuestas where id_res=2");

    $row = mysqli_fetch_row($result);
    
     $res1=$row[0];
     $res2=$row[1];
     $res3=$row[2];
     $res4=$row[3]; 

   echo "<tr>";
   echo "<td width='51'>$res1<input type='radio' name='opcion1' value='$res1'";
   echo "<td width='51'>$res2<input type='radio' name='opcion1' value='$res2'";
   echo "<td width='51'>$res3<input type='radio' name='opcion1' value='$res3'";
   echo "<td width='51'>$res4<input type='radio' name='opcion1' value='$res4'";
   echo "</tr>";
   echo "</table>";


   // prueba 3

   $result= mysqli_query($con,"select * from pregunta where id_pre=3");

    $row = mysqli_fetch_row($result);
    
     $id=$row[0];
     $nom=$row[1];   
         

    
    echo "<br>";
    echo "<table width='400' border='3'>";
    echo "<tr>"; 
    echo "<td colpan='2'><strong>Pregunta</strong>: $nom"; 
    echo "</tr>";
    $result= mysqli_query($con,"select res1,res2,res3,res4 from respuestas where id_res=3");

    $row = mysqli_fetch_row($result);
    
     $res1=$row[0];
     $res2=$row[1];
     $res3=$row[2];
     $res4=$row[3]; 

   echo "<tr>";
   echo "<td width='51'>$res1<input type='radio' name='opcion2' value='$res1'";
   echo "<td width='51'>$res2<input type='radio' name='opcion2' value='$res2'";
   echo "<td width='51'>$res3<input type='radio' name='opcion2' value='$res3'";
   echo "<td width='51'>$res4<input type='radio' name='opcion2' value='$res4'";
   echo "</tr>";
   echo "</table>";

   // prueba 4

   $result= mysqli_query($con,"select * from pregunta where id_pre=4");

    $row = mysqli_fetch_row($result);
    
     $id=$row[0];
     $nom=$row[1];   
         

    
    echo "<br>";
    echo "<table width='400' border='3'>";
    echo "<tr>"; 
    echo "<td colpan='2'><strong>Pregunta</strong>: $nom"; 
    echo "</tr>";
    $result= mysqli_query($con,"select res1,res2,res3,res4 from respuestas where id_res=4");

    $row = mysqli_fetch_row($result);
    
     $res1=$row[0];
     $res2=$row[1];
     $res3=$row[2];
     $res4=$row[3]; 

   echo "<tr>";
   echo "<td width='51'>$res1<input type='radio' name='opcion3' value='$res1'";
   echo "<td width='51'>$res2<input type='radio' name='opcion3' value='$res2'";
   echo "<td width='51'>$res3<input type='radio' name='opcion3' value='$res3'";
   echo "<td width='51'>$res4<input type='radio' name='opcion3' value='$res4'";
   echo "</tr>";
   echo "</table>";

   // prueba 5

   $result= mysqli_query($con,"select * from pregunta where id_pre=5");

    $row = mysqli_fetch_row($result);
    
     $id=$row[0];
     $nom=$row[1];   
         

    
    echo "<br>";
    echo "<table width='400' border='3'>";
    echo "<tr>"; 
    echo "<td colpan='2'><strong>Pregunta</strong>: $nom"; 
    echo "</tr>";
    $result= mysqli_query($con,"select res1,res2,res3,res4 from respuestas where id_res=5");

    $row = mysqli_fetch_row($result);
    
     $res1=$row[0];
     $res2=$row[1];
     $res3=$row[2];
     $res4=$row[3]; 

   echo "<tr>";
   echo "<td width='51'>$res1<input type='radio' name='opcion4' value='$res1'";
   echo "<td width='51'>$res2<input type='radio' name='opcion4' value='$res2'";
   echo "<td width='51'>$res3<input type='radio' name='opcion4' value='$res3'";
   echo "<td width='51'>$res4<input type='radio' name='opcion4' value='$res4'";
   echo "</tr>";
   echo "</table>";

   // prueba 6

   $result= mysqli_query($con,"select * from pregunta where id_pre=6");

    $row = mysqli_fetch_row($result);
    
     $id=$row[0];
     $nom=$row[1];   
         

    
    echo "<br>";
    echo "<table width='400' border='3'>";
    echo "<tr>"; 
    echo "<td colpan='2'><strong>Pregunta</strong>: $nom"; 
    echo "</tr>";
    $result= mysqli_query($con,"select res1,res2,res3,res4 from respuestas where id_res=6");

    $row = mysqli_fetch_row($result);
    
     $res1=$row[0];
     $res2=$row[1];
     $res3=$row[2];
     $res4=$row[3]; 

   echo "<tr>";
   echo "<td width='51'>$res1<input type='radio' name='opcion5' value='$res1'";
   echo "<td width='51'>$res2<input type='radio' name='opcion5' value='$res2'";
   echo "<td width='51'>$res3<input type='radio' name='opcion5' value='$res3'";
   echo "<td width='51'>$res4<input type='radio' name='opcion5' value='$res4'";
   echo "</tr>";
   echo "</table>";

   // prueba 7

   $result= mysqli_query($con,"select * from pregunta where id_pre=7");

    $row = mysqli_fetch_row($result);
    
     $id=$row[0];
     $nom=$row[1];   
         

    
    echo "<br>";
    echo "<table width='400' border='3'>";
    echo "<tr>"; 
    echo "<td colpan='2'><strong>Pregunta</strong>: $nom"; 
    echo "</tr>";
    $result= mysqli_query($con,"select res1,res2,res3,res4 from respuestas where id_res=7");

    $row = mysqli_fetch_row($result);
    
     $res1=$row[0];
     $res2=$row[1];
     $res3=$row[2];
     $res4=$row[3]; 

   echo "<tr>";
   echo "<td width='51'>$res1<input type='radio' name='opcion6' value='$res1'";
   echo "<td width='51'>$res2<input type='radio' name='opcion6' value='$res2'";
   echo "<td width='51'>$res3<input type='radio' name='opcion6' value='$res3'";
   echo "<td width='51'>$res4<input type='radio' name='opcion6' value='$res4'";
   echo "</tr>";
   echo "</table>";

   // prueba 8

   $result= mysqli_query($con,"select * from pregunta where id_pre=8");

    $row = mysqli_fetch_row($result);
    
     $id=$row[0];
     $nom=$row[1];   
         

    
    echo "<br>";
    echo "<table width='400' border='3'>";
    echo "<tr>"; 
    echo "<td colpan='2'><strong>Pregunta</strong>: $nom"; 
    echo "</tr>";
    $result= mysqli_query($con,"select res1,res2,res3,res4 from respuestas where id_res=8");

    $row = mysqli_fetch_row($result);
    
     $res1=$row[0];
     $res2=$row[1];
     $res3=$row[2];
     $res4=$row[3]; 

   echo "<tr>";
   echo "<td width='51'>$res1<input type='radio' name='opcion7' value='$res1'";
   echo "<td width='51'>$res2<input type='radio' name='opcion7' value='$res2'";
   echo "<td width='51'>$res3<input type='radio' name='opcion7' value='$res3'";
   echo "<td width='51'>$res4<input type='radio' name='opcion7' value='$res4'";
   echo "</tr>";
   echo "</table>";

   // prueba 9

   $result= mysqli_query($con,"select * from pregunta where id_pre=9");

    $row = mysqli_fetch_row($result);
    
     $id=$row[0];
     $nom=$row[1];   
         

    
    echo "<br>";
    echo "<table width='400' border='3'>";
    echo "<tr>"; 
    echo "<td colpan='2'><strong>Pregunta</strong>: $nom"; 
    echo "</tr>";
    $result= mysqli_query($con,"select res1,res2,res3,res4 from respuestas where id_res=9");

    $row = mysqli_fetch_row($result);
    
     $res1=$row[0];
     $res2=$row[1];
     $res3=$row[2];
     $res4=$row[3]; 

   echo "<tr>";
   echo "<td width='51'>$res1<input type='radio' name='opcion8' value='$res1'";
   echo "<td width='51'>$res2<input type='radio' name='opcion8' value='$res2'";
   echo "<td width='51'>$res3<input type='radio' name='opcion8' value='$res3'";
   echo "<td width='51'>$res4<input type='radio' name='opcion8' value='$res4'";
   echo "</tr>";
   echo "</table>";

   // prueba 10

   $result= mysqli_query($con,"select * from pregunta where id_pre=10");

    $row = mysqli_fetch_row($result);
    
     $id=$row[0];
     $nom=$row[1];   
         

    
    echo "<br>";
    echo "<table width='400' border='3'>";
    echo "<tr>"; 
    echo "<td colpan='2'><strong>Pregunta</strong>: $nom"; 
    echo "</tr>";
    $result= mysqli_query($con,"select res1,res2,res3,res4 from respuestas where id_res=10");

    $row = mysqli_fetch_row($result);
    
     $res1=$row[0];
     $res2=$row[1];
     $res3=$row[2];
     $res4=$row[3]; 

   echo "<tr>";
   echo "<td width='51'>$res1<input type='radio' name='opcion9' value='$res1'";
   echo "<td width='51'>$res2<input type='radio' name='opcion9' value='$res2'";
   echo "<td width='51'>$res3<input type='radio' name='opcion9' value='$res3'";
   echo "<td width='51'>$res4<input type='radio' name='opcion9' value='$res4'";
   echo "</tr>";
   echo "</table>";
   echo "</center>";
   echo "<br>";
echo "<center>";
   echo "<input type='submit' name='in' value='Responder'>";
   echo "</center>";
echo "</form>";
echo "</div>";
echo "</body>";


 }


 public function resulado($a,$b,$c,$d,$e,$f,$g,$h,$i,$j)
 {
    $con = mysqli_connect("localhost:3306","root","","easywork") or die(mysql_error());

     // resulado prueba 1

    $result= mysqli_query($con,"select verd from respuestas where id_res=1");

    $row = mysqli_fetch_row($result);
    echo "<table border='5'>";
    echo "<tr>";
    echo "<td>";
     $res1=$row[0];
   if($a==$res1)
   {
    $bandera=1;
    echo "correcta";
   }
   else
   {
       echo "incorrecta";
   }
   echo "<br>";
// resulado pregunta 2 

$result= mysqli_query($con,"select verd from pre where id_pre=2");

    $row = mysqli_fetch_row($result);
    
     $res=$row[0];

   if($b==$res)
   {
    $bandera=1;
    echo "correcta";
}
else
{
    echo "incorrecta";
}
echo "<br>";
// pregunta 3

$result= mysqli_query($con,"select verd from pre where id_pre=3");

    $row = mysqli_fetch_row($result);
    
     $res1=$row[0];

   if($c==$res1)
   {
       $bandera=1;
    echo "correcta";
}
else
{
    echo "incorrecta";
}
echo "<br>";
// prueba 4

$result= mysqli_query($con,"select verd from pre where id_pre=4");

    $row = mysqli_fetch_row($result);
    
     $res1=$row[0];

   if($d==$res1)
   {
    $bandera=1;
    echo "correcta";
}
else
{
    echo "incorrecta";
}
echo "<br>";
// pregunta 5

$result= mysqli_query($con,"select verd from pre where id_pre=5");

    $row = mysqli_fetch_row($result);
    
     $res1=$row[0];

   if($e==$res1)
   {
    $bandera=1;
    echo "correcta";
}
else
{
    
    echo "incorrecta";
}
echo "<br>";
// pregunta 6

$result= mysqli_query($con,"select verd from pre where id_pre=6");

    $row = mysqli_fetch_row($result);
    
     $res1=$row[0];

   if($f==$res1)
   {
    $bandera=1;
    echo "correcta";
}
else
{
    echo "incorrecta";
}
   
echo "<br>";
   // pregunta 7

   $result= mysqli_query($con,"select verd from pre where id_pre=7");

    $row = mysqli_fetch_row($result);
    
     $res1=$row[0];

   if($g==$res1)
   {
    $bandera=1;
    echo "correcta";
}
else
{
    echo "incorrecta";
}
echo "<br>";
// pregunta 8
$result= mysqli_query($con,"select verd from pre where id_pre=8");

    $row = mysqli_fetch_row($result);
    
     $res1=$row[0];

   if($h==$res1)
   {
    $bandera=1;
    echo "correcta";
}
else
{
    echo "incorrecta";
}
echo "<br>";
// pregunta 9

$result= mysqli_query($con,"select verd from pre where id_pre=9");

    $row = mysqli_fetch_row($result);
    
     $res1=$row[0];

   if($i==$res1)
   {
    $bandera=1;
    echo "correcta";
}
else
{
    echo "incorrecta";
}
echo "<br>";
// pregunta 10

$result= mysqli_query($con,"select verd from respuestas where id_res=10");

    $row = mysqli_fetch_row($result);
    
     $res1=$row[0];

   if($j==$res1)
    {
    $bandera=1;
    echo "correcta";
    }
    else
{
    echo "incorrecta";
}

   
    }


}




 



?>
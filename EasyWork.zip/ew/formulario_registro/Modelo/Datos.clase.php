<?php
class Datos {


    public $Doc;  
    public $nombre;
    public $SegNom; 
    public $Ape;
    public $SegApe;
    public $Cel;   
    public $Email;
    public $Clav;
    public $Cargo;    
    public $Estado; 
     
       

	public function __construct () {
        
        $this->Doc = 0;
        $this->nombre = '';
        $this->SegNom = '';
        $this->Ape = '';
        $this->SegApe = '';
        $this->Cel = 0;
        $this->Email = '';
        $this->Clav = '';
        $this->Cargo = '';
        $this->Estado= 1;
        
        
        
	}
}

?>
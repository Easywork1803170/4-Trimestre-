<?php
require_once '../Modelo/Conexion.clase.php';
require_once '../Modelo/Datos.clase.php';

class DatosDAO {


	public static function ingresarDato($rol) {
		$con = new Conexion();
		
		$con->ejecutarActualizacion("INSERT INTO usuario values($rol->Doc,'$rol->nombre','$rol->SegNom','$rol->Ape','$rol->SegApe',$rol->Cel,'$rol->Email','$rol->Clav',$rol->Cargo,1)");
		$con->cerrarConexion();
	}






}

?>
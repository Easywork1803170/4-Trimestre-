<?php

require_once '../Modelo/Datos.clase.php';
require_once '../dao/Datos.dao.php';




        $r = new Datos();
        $r->Doc = $_POST['doc'];
        $r->SegNom = $_POST['nom2'];
        $r->nombre = $_POST['nom'];
        $r->Ape = $_POST['ape'];
        $r->SegApe = $_POST['ape2'];
        $r->Cel = $_POST['cel'];
        $r->Email = $_POST['email'];
        $r->Clav = $_POST['pa'];
        $r->Cargo = $_POST['op'];
        $r->estado = 2;
       
      

		DatosDAO::ingresarDato($r);
 



    require_once("../Vista/Vista.php");
    

?>
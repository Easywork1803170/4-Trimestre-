<?php
	class Modelo_Persona{
		private $db;
		public function __construct(){
			require_once('modelo_conexion.php');
			$this->conexion = new conexion();
			$this->conexion->conectar();
		}

			function listar_persona($valor, $inicio=FALSE,$limite=FALSE){
				if ($inicio!==FALSE && $limite!==FALSE) {
				    $sql = "SELECT * FROM usuario WHERE doc LIKE '".$valor."%' LIMIT $inicio,$limite";
				}else{
				    $sql = "SELECT * FROM usuario WHERE doc LIKE '".$valor."%'";
				}
				$resultado =  $this->conexion->conexion->query($sql);

				$arreglo = array();
				while($consulta_VU=mysqli_fetch_array($resultado)){ ///MYSQL_BOTH, MYSQL_ASSOC, MYSQL_NUM
				    $arreglo[] = $consulta_VU;
				}
				return $arreglo;
		 		$this->conexion->cerrar();	
			}


			function Modificar_Persona($idpersona,$pNombre,$sNombre,$papellido,$sapellido,$correo,$cargo,$estado){
			$sql = "call PA_MODIFICARPERSONA('$idpersona','$pNombre','$sNombre','$papellido','$sapellido','$correo','$cargo','$estado')";

			if($resultado = $this->conexion->conexion->query($sql)){
				$id_retornado = mysqli_insert_id($this->conexion->conexion);
								return 1;

				}else {

					return 0;
				}
				$this->conexion->Cerrar();
				
			}


	}
?>
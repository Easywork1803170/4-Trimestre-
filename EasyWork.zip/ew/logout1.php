<?php


session_start();


   if(isset($_SESSION['Userame'])){

 header('location:location:Aspirante Easy Work/Principal.php');
  

   }



?>